/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.messageapp;
import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author thoko
 */
public class Message {
    private static int messageCounter = 0;

    private String messageID;
    private String recipientCell;
    private String messageText;
    private String messageHash;
    private int numMessagesSent;

    // Constructor 
    public void Message(String recipientCell, String messageText) {
        this.numMessagesSent = ++messageCounter;
        this.messageID = generateMessageID();
        this.recipientCell = recipientCell;
        this.messageText = messageText != null ? messageText : "";
        this.messageHash = createMessageHash();
    }

    private String generateMessageID() {
        Random rand = new Random();
        return String.format("%010d", rand.nextInt(1000000000));
    }

    public boolean checkMessageID() {
        return messageID != null && messageID.length() == 10;
    }

    public String checkRecipientCell(String cell) {
        if (cell == null || cell.length() > 10 || !cell.matches(".*\\d.*")) {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
        this.recipientCell = cell;
        return "Cell phone number successfully captured.";
    }

    public String createMessageHash() {
        if (messageText == null || messageText.trim().isEmpty()) {
            return "00:0:EMPTY";
        }
        String firstTwo = messageID.substring(0, 2);
        String[] words = messageText.trim().split("\\s+");
        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length - 1].toUpperCase();
        return firstTwo + ":" + (numMessagesSent - 1) + ":" + firstWord + lastWord;
    }

    public String SentMessage() {
        if (messageText.length() > 250) {
            int excess = messageText.length() - 250;
            return "Message exceeds 250 characters by " + excess + " characters; please reduce the size.";
        }
        return "Message ready to send.";
    }

    public String printMessages() {
        return "Message ID: " + messageID + "\n" +
               "Message Hash: " + messageHash + "\n" +
               "Recipient: " + recipientCell + "\n" +
               "Message: " + messageText;
    }

    public int returnTotalMessages() {
        return messageCounter;
    }

    public String storeMessage() {
        try (FileWriter file = new FileWriter("messages.json", true)) {
            String json = "{\"messageID\":\"" + messageID + "\",\"hash\":\"" + messageHash + 
                         "\",\"recipient\":\"" + recipientCell + "\",\"message\":\"" + 
                         messageText.replace("\"", "\\\"") + "\"}\n";
            file.write(json + ",\n");
            return "Message successfully stored.";
        } catch (IOException e) {
            return "Error storing message.";
        }
    }

    // Getters
    public String getMessageID() { return messageID; }
    public String getMessageHash() { return messageHash; }
}
