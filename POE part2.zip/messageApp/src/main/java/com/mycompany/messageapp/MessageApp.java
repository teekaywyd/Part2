/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.messageapp;

import java.util.ArrayList;
import java.util.Scanner;

public class MessageApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();
        ArrayList<Message> messages = new ArrayList<>();

        // ==================== REGISTRATION & LOGIN ====================
        System.out.println("=== QUICKCHAT REGISTRATION ===");
        
        System.out.print("Enter username (e.g. kyl_1): ");
        String username = scanner.nextLine();
        
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        
        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();
        
        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();
        
        System.out.print("Enter South African cell number (e.g. +27718693002): ");
        String cellPhone = scanner.nextLine();

        // Register user
        String regResult = login.registerUser(username, password, firstName, lastName, cellPhone);
        System.out.println(regResult);

        if (!regResult.contains("successfully")) {
            System.out.println("Registration failed. Exiting...");
            scanner.close();
            return;
        }

        // Login
        System.out.println("\n=== LOGIN ===");
        boolean loggedIn = false;
        while (!loggedIn) {
            System.out.print("Username: ");
            String user = scanner.nextLine();
            System.out.print("Password: ");
            String pass = scanner.nextLine();
            
            loggedIn = login.loginUser(user, pass);
            System.out.println(login.returnLoginStatus(loggedIn, firstName, lastName));
        }

        // ==================== SENDING MESSAGES ====================
        System.out.println("\nWelcome to QuickChat.");

        System.out.print("How many messages would you like to enter? ");
        int totalToSend = scanner.nextInt();
        scanner.nextLine(); // consume newline

        for (int i = 0; i < totalToSend; i++) {
            System.out.println("\n--- Message " + (i + 1) + " ---");

            System.out.print("Enter recipient cell: ");
            String recipient = scanner.nextLine();

            System.out.print("Enter your message (max 250 chars): ");
            String text = scanner.nextLine();

            Message msg = new Message();

            System.out.println(msg.SentMessage());
            System.out.println("\n" + msg.printMessages());

            // User choice menu
            System.out.println("\n1. Send Message");
            System.out.println("2. Disregard Message");
            System.out.println("3. Store Message");
            System.out.print("Choose option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> System.out.println("Message successfully sent.");
                case 2 -> System.out.println("Press 0 to delete the message.");
                case 3 -> System.out.println(msg.storeMessage());
                default -> System.out.println("Invalid option.");
            }

            messages.add(msg);
        }

        if (!messages.isEmpty()) {
            System.out.println("\nTotal messages sent: " + messages.get(0).returnTotalMessages());
        }
        System.out.println("Thank you for using QuickChat!");
        scanner.close();
    }
}