/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.messageapp;

/**
 *
 * @author thoko
 */
public class Login {
    
    private String regUsername;
    private String regPassword;
    private String firstName; 
    private String lastName;
    
    public boolean checkUserName(String username){
        return username != null && username.contains("_") && username.length() <= 5;
    }
    
    public boolean checkPasswordComplexity(String password){
        
        if( password == null || password.length() < 8)
            return false;
        
        boolean hasCapitalLetter = false;
        boolean hasNumber = false;
        boolean hasSpecialChar = false;
        
        for(char c: password.toCharArray()){
            if(Character.isUpperCase(c))
                hasCapitalLetter = true;
            
            if(Character.isDigit(c))
                hasNumber = true;
            
            if(Character.isLetterOrDigit(c))
                hasSpecialChar = true;
        }
         return hasCapitalLetter && hasNumber && hasSpecialChar;
    }
    
   
     
    public boolean checkCellPhoneNumber (String cellPhone){
        
        if(cellPhone == null){
        
        return false;
        }
        return cellPhone.matches("^\\+27\\d{9}$");
        
    }
    
    public String registerUser(String password, String username, String cellPhone, String firstName, String lastName){
        
        if(!checkUserName(username)){
            return "Username is not correctly formatted; please ensure that the password contains an underscore and is no more than 5 characters in length.";
        }
        if(!checkPasswordComplexity(password)){
            return "Password is not correctly formatted; please ensure that the password contains atleast eight characters, a capital letter, a special character, and a number";
        }
        if(!checkCellPhoneNumber(cellPhone)){
            return "Cell Phone number incorrectly formatted or does not contain an international code; please correct the number and try again.";
        }
        
        this.regPassword = password;
        this.regUsername = username;
        this.firstName = firstName;
        this.lastName = lastName;
        
        return "Username, password and cell number successfully captured.";
       
        
    }
    
    public boolean loginUser(String username, String password){
        
        return regUsername != null && regUsername.equals(username) && regPassword != null && regPassword.equals(password);
        
    }
    
    public String returnLoginStatus(boolean loginSuccess, String firstName, String lastName){
        if(loginSuccess){
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        }
        else {
            return "Username or password incorrect, please try again.";
        }
    }
    
    
    
}
