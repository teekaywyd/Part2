import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import com.mycompany.messageapp.Message;

class messageTest {

    Message msg = new Message();  // Shared instance like in LoginTest

    @Test
    void testMessageLengthSuccess() {
        assertEquals("Message ready to send.", msg.SentMessage());
    }

    @Test
    void testMessageLengthFailure() {
       
        String result = msg.SentMessage();
        assertTrue(result.contains("exceeds 250 characters"));
    }

    @Test
    void testRecipientCell() {
        assertEquals("Cell phone number successfully captured.",msg.checkRecipientCell("+27718693002"));
    }

    @Test
    void testMessageHash() {
        String hash = msg.createMessageHash();
        assertTrue(hash.startsWith("00:") && hash.contains(":HI") && hash.endsWith("TONIGHT?"));
    }

    @Test
    void testTotalMessages() {
       
        assertTrue(msg.returnTotalMessages() >= 2);
    }

    @Test
    void testMessageID() {
        assertTrue(msg.checkMessageID());
    }
}